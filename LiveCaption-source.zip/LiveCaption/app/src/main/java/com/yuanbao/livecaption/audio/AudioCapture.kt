package com.yuanbao.livecaption.audio

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import android.util.Log

/**
 * 音频采集：
 *  - startPlaybackCapture：Android 10+ 通过 MediaProjection 只捕获 APP 内部播放的声音
 *  - startMic：麦克风兜底（录外放声音）
 * 统一输出 16kHz / 单声道 / PCM16
 */
class AudioCapture(private val sampleRate: Int = 16000) {

    companion object {
        private const val TAG = "AudioCapture"
    }

    private var recorder: AudioRecord? = null

    private val bufferSize: Int
        get() {
            val min = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            return maxOf(min, 4096) * 2
        }

    private fun format(): AudioFormat = AudioFormat.Builder()
        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
        .setSampleRate(sampleRate)
        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
        .build()

    @SuppressLint("MissingPermission")
    fun startMic() {
        val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                .setAudioFormat(format())
                .setBufferSizeInBytes(bufferSize)
                .build()
        } else {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        }
        finishStart(rec, "mic")
    }

    fun startPlaybackCapture(projection: MediaProjection) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            throw IllegalStateException("内录需要 Android 10 及以上")
        }
        val config = AudioPlaybackCaptureConfiguration.Builder(projection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()

        val rec = AudioRecord.Builder()
            .setAudioFormat(format())
            .setAudioPlaybackCaptureConfig(config)
            .setBufferSizeInBytes(bufferSize)
            .build()
        finishStart(rec, "internal")
    }

    private fun finishStart(rec: AudioRecord, tag: String) {
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw IllegalStateException("AudioRecord 初始化失败($tag)，可能不被支持或未授权")
        }
        rec.startRecording()
        recorder = rec
        Log.i(TAG, "started: $tag @ ${sampleRate}Hz")
    }

    /** 阻塞读取，返回读取到的样本数；<=0 表示失败 */
    fun read(out: ShortArray): Int {
        val rec = recorder ?: return -1
        return try {
            val n = rec.read(out, 0, out.size, AudioRecord.READ_BLOCKING)
            if (n > 0) n else -1
        } catch (t: Throwable) {
            Log.w(TAG, "read failed", t)
            -1
        }
    }

    fun stop() {
        try {
            recorder?.stop()
        } catch (t: Throwable) {
            Log.w(TAG, "stop failed", t)
        }
        recorder?.release()
        recorder = null
    }
}
