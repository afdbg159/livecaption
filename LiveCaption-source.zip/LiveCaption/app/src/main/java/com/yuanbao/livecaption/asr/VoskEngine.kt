package com.yuanbao.livecaption.asr

import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

/**
 * 本地离线中文识别（Vosk / Kaldi）。
 * 完全离线、不联网、不上传音频；额外提供 partial 结果用于实时滚动字幕。
 */
class VoskEngine(
    private val modelDir: String,
    private val sampleRate: Float = 16000f
) : AsrEngine {

    companion object {
        private const val TAG = "VoskEngine"
    }

    private var model: Model? = null
    private var recognizer: Recognizer? = null

    override fun start(): Boolean {
        return try {
            val m = Model(modelDir)
            val r = Recognizer(m, sampleRate).apply {
                setWords(true)
                setPartialWords(true)
            }
            model = m
            recognizer = r
            Log.i(TAG, "vosk model loaded: $modelDir")
            true
        } catch (t: Throwable) {
            Log.e(TAG, "load model failed", t)
            false
        }
    }

    override fun accept(samples: FloatArray, sampleRate: Int): String? {
        val r = recognizer ?: return null
        val shorts = toShorts(samples)
        val ready = try {
            r.acceptWaveForm(shorts, shorts.size)
        } catch (t: Throwable) {
            Log.w(TAG, "acceptWaveForm failed", t)
            return null
        }
        return if (ready) text(r.result) else null
    }

    override fun partial(): String? {
        val r = recognizer ?: return null
        return try {
            text(r.partialResult())
        } catch (t: Throwable) {
            null
        }
    }

    override fun flush(): String? {
        val r = recognizer ?: return null
        return try {
            text(r.finalResult)
        } catch (t: Throwable) {
            null
        }
    }

    override fun release() {
        try {
            recognizer?.close()
            model?.close()
        } catch (t: Throwable) {
            Log.w(TAG, "release failed", t)
        }
        recognizer = null
        model = null
    }

    private fun toShorts(samples: FloatArray): ShortArray {
        val out = ShortArray(samples.size)
        for (i in samples.indices) {
            val v = samples[i]
            val s = (v * 32767f).toInt().coerceIn(-32768, 32767)
            out[i] = s.toShort()
        }
        return out
    }

    private fun text(json: String?): String? {
        if (json.isNullOrBlank()) return null
        return try {
            JSONObject(json).optString("text", "").trim().ifBlank { null }
        } catch (t: Throwable) {
            null
        }
    }
}
