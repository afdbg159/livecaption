package com.yuanbao.livecaption.util

import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * 腾讯云 API 3.0（TC3-HMAC-SHA256）签名，用于云端 ASR。
 */
object TCloudSigner {

    private const val ALGORITHM = "TC3-HMAC-SHA256"

    fun sign(
        secretId: String,
        secretKey: String,
        host: String,
        service: String,
        action: String,
        payload: String,
        timestamp: Long
    ): String {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }.format(Date(timestamp * 1000))

        val contentType = "application/json; charset=utf-8"
        val canonicalHeaders = "content-type:$contentType\nhost:$host\nx-tc-action:${action.lowercase(Locale.US)}\n"
        val signedHeaders = "content-type;host;x-tc-action"
        val hashedPayload = sha256Hex(payload.toByteArray(Charsets.UTF_8))

        val canonicalRequest = buildString {
            append("POST\n")
            append("/\n")
            append("\n")
            append(canonicalHeaders).append("\n")
            append(signedHeaders).append("\n")
            append(hashedPayload)
        }

        val credentialScope = "$date/$service/tc3_request"
        val stringToSign = "$ALGORITHM\n$timestamp\n$credentialScope\n" +
            sha256Hex(canonicalRequest.toByteArray(Charsets.UTF_8))

        val secretDate = hmac("TC3$secretKey".toByteArray(Charsets.UTF_8), date)
        val secretService = hmac(secretDate, service)
        val secretSigning = hmac(secretService, "tc3_request")
        val signature = hex(hmac(secretSigning, stringToSign))

        return "$ALGORITHM Credential=$secretId/$credentialScope, " +
            "SignedHeaders=$signedHeaders, Signature=$signature"
    }

    private fun hmac(key: ByteArray, data: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(data.toByteArray(Charsets.UTF_8))
    }

    private fun sha256Hex(data: ByteArray): String =
        hex(MessageDigest.getInstance("SHA-256").digest(data))

    private fun hex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) sb.append(String.format("%02x", b))
        return sb.toString()
    }
}
