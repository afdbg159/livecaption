package com.yuanbao.livecaption

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.yuanbao.livecaption.asr.AsrEngine
import com.yuanbao.livecaption.asr.CloudAsrEngine
import com.yuanbao.livecaption.asr.VoskEngine
import com.yuanbao.livecaption.audio.AudioCapture
import com.yuanbao.livecaption.audio.VadSegmenter
import com.yuanbao.livecaption.model.ModelManager
import com.yuanbao.livecaption.util.CaptionWriter
import com.yuanbao.livecaption.util.Prefs
import java.io.File

/**
 * 前台服务：采集音频 -> 中文识别 -> 悬浮窗字幕 + SRT 落盘。
 */
class CaptionService : Service() {

    companion object {
        private const val TAG = "CaptionService"

        const val ACTION_START = "com.yuanbao.livecaption.action.START"
        const val ACTION_STOP = "com.yuanbao.livecaption.action.STOP"

        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_MODE = "extra_mode"
        const val EXTRA_ENGINE = "extra_engine"

        const val BROADCAST_CAPTION = "com.yuanbao.livecaption.CAPTION"
        const val EXTRA_TEXT = "extra_text"
        const val EXTRA_ERROR = "extra_error"
        const val EXTRA_SRT = "extra_srt"
        const val EXTRA_STATE = "extra_state"

        private const val CHANNEL_ID = "livecaption"
        private const val NOTIFY_ID = 1001

        const val SAMPLE_RATE = 16000
    }

    private lateinit var overlay: OverlayWindow
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var running = false

    private var engine: AsrEngine? = null
    private var capture: AudioCapture? = null
    private var projection: MediaProjection? = null
    private var writer: CaptionWriter? = null
    private var worker: Thread? = null
    private var speechStarted = false

    override fun onCreate() {
        super.onCreate()
        overlay = OverlayWindow(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val mode = intent.getStringExtra(EXTRA_MODE) ?: Prefs.MODE_MIC
                val engineType = intent.getStringExtra(EXTRA_ENGINE) ?: Prefs.ENGINE_LOCAL
                startForeground(NOTIFY_ID, buildNotification())

                val data = projectionData(intent)
                if (data != null) {
                    val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projection = mgr.getMediaProjection(Activity.RESULT_OK, data)
                }
                worker = Thread({ runPipeline(mode, engineType) }, "asr-loop").apply { start() }
            }
        }
        return START_STICKY
    }

    private fun projectionData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }

    /** 后台线程：加载引擎 -> 打开音频 -> 循环识别 */
    private fun runPipeline(mode: String, engineType: String) {
        if (running) return

        val eng: AsrEngine = when (engineType) {
            Prefs.ENGINE_CLOUD -> CloudAsrEngine(Prefs.getSecretId(this), Prefs.getSecretKey(this))
            else -> {
                val dir = ModelManager.findModelDir(this)
                if (dir == null) {
                    fail("本地引擎需要模型：请先点「下载离线模型」")
                    return
                }
                VoskEngine(dir, SAMPLE_RATE.toFloat())
            }
        }

        broadcast(text = null, error = null, state = "正在加载引擎…")
        if (!eng.start()) {
            fail("引擎初始化失败：本地引擎请确认模型完整，云端引擎请确认密钥")
            eng.release()
            return
        }
        engine = eng

        val cap = AudioCapture(SAMPLE_RATE)
        var internalOk = false
        if (mode == Prefs.MODE_INTERNAL && projection != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            internalOk = try {
                cap.startPlaybackCapture(projection!!)
                true
            } catch (t: Throwable) {
                Log.w(TAG, "playback capture failed", t)
                false
            }
        }
        if (!internalOk) {
            try {
                cap.startMic()
                if (mode == Prefs.MODE_INTERNAL) {
                    broadcast(null, "该 APP 不允许内录，已切换为麦克风")
                }
            } catch (t: Throwable) {
                Log.e(TAG, "mic start failed", t)
                fail("无法开始录音，请检查麦克风权限")
                return
            }
        }
        capture = cap

        val stamp = System.currentTimeMillis()
        writer = CaptionWriter(File(getExternalFilesDir("captions"), "caption-$stamp.srt"))
        overlay.show()
        running = true
        broadcast(null, null, state = "字幕已开启")
        Log.i(TAG, "pipeline started, mode=$mode, engine=$engineType")

        val vad = VadSegmenter(SAMPLE_RATE)
        val buf = ShortArray(SAMPLE_RATE / 10)   // 100ms
        var segmentStart = System.currentTimeMillis()

        while (running) {
            val n = cap.read(buf)
            if (n <= 0) continue
            val floats = FloatArray(n)
            for (i in 0 until n) floats[i] = buf[i] / 32768f

            vad.feed(
                floats,
                onSpeech = { chunk ->
                    if (!speechStarted) {
                        speechStarted = true
                        segmentStart = System.currentTimeMillis()
                    }
                    val finalText = eng.accept(chunk, SAMPLE_RATE)
                    if (!finalText.isNullOrBlank()) {
                        emit(finalText, segmentStart)
                        speechStarted = false
                        vad.reset()
                    } else {
                        // 实时滚动：显示还没说完的部分
                        eng.partial()?.let { p ->
                            if (p.isNotBlank()) overlay.update(p)
                        }
                    }
                },
                onSegmentEnd = {
                    val text = eng.flush()
                    if (!text.isNullOrBlank()) emit(text, segmentStart)
                    speechStarted = false
                }
            )
        }
    }

    private fun emit(raw: String, startMs: Long) {
        val text = raw.trim().replace(Regex("\\s+"), "")
        if (text.isEmpty()) return
        writer?.append(startMs, System.currentTimeMillis(), text)
        overlay.update(text)
        broadcast(text, null)
    }

    private fun fail(error: String) {
        broadcast(null, error, state = null)
        mainHandler.post { stopSelf() }
    }

    private fun broadcast(text: String?, error: String?, state: String? = null) {
        sendBroadcast(
            Intent(BROADCAST_CAPTION)
                .setPackage(packageName)
                .putExtra(EXTRA_TEXT, text)
                .putExtra(EXTRA_ERROR, error)
                .putExtra(EXTRA_STATE, state)
                .putExtra(EXTRA_SRT, writer?.path())
        )
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notify_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notify_text))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        running = false
        try {
            worker?.join(2000)
        } catch (t: Throwable) {
            Log.w(TAG, "join failed", t)
        }
        capture?.stop()
        engine?.release()
        overlay.hide()
        runCatching { projection?.stop() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
        Log.i(TAG, "stopped")
    }
}
