package com.yuanbao.livecaption.util

import java.io.File
import java.util.Locale

/**
 * 把识别结果写成标准 SRT 字幕文件。
 */
class CaptionWriter(private val file: File) {

    private var index = 0

    init {
        file.parentFile?.mkdirs()
        if (!file.exists()) file.writeText("", Charsets.UTF_8)
    }

    @Synchronized
    fun append(startMs: Long, endMs: Long, text: String) {
        index++
        file.appendText(
            "$index\n${stamp(startMs)} --> ${stamp(endMs)}\n$text\n\n",
            Charsets.UTF_8
        )
    }

    fun path(): String = file.absolutePath

    private fun stamp(ms: Long): String {
        val h = ms / 3_600_000
        val m = (ms % 3_600_000) / 60_000
        val s = (ms % 60_000) / 1_000
        val rest = ms % 1_000
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, rest)
    }
}
