package com.yuanbao.livecaption.asr

/**
 * 语音识别引擎统一接口。
 *
 * accept() 返回非 null 表示一句话已识别完成（可写入字幕）；
 * partial() 返回当前这句话的中间结果（用于实时滚动字幕，不落盘）。
 */
interface AsrEngine {
    fun start(): Boolean
    fun accept(samples: FloatArray, sampleRate: Int): String?
    fun partial(): String?
    fun flush(): String?
    fun release()
}
