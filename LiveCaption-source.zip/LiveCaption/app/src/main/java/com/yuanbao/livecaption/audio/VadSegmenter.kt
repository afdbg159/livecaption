package com.yuanbao.livecaption.audio

import kotlin.math.log10
import kotlin.math.sqrt

/**
 * 极简能量 VAD：把连续音频切成"一句话"，用于分句识别与断句。
 * 只要在安静环境下使用就足够；吵闹环境建议改用 sherpa-onnx 自带的 silero VAD。
 */
class VadSegmenter(
    private val sampleRate: Int,
    private val startSpeechMs: Int = 150,   // 连续多久的能量算真正说话
    private val endSilenceMs: Int = 600,    // 静音多久判定一句话结束
    private val speechDb: Float = -45f      // 能量阈值（dB）
) {
    private var inSpeech = false
    private var speechMs = 0
    private var silenceMs = 0

    /**
     * @param onSpeech 属于当前这句话的音频（含尾部少量静音，利于端点检测）
     * @param onSegmentEnd 一句话结束
     */
    fun feed(chunk: FloatArray, onSpeech: (FloatArray) -> Unit, onSegmentEnd: () -> Unit) {
        val durMs = (chunk.size * 1000L / sampleRate).toInt()
        val loud = rmsToDb(chunk) >= speechDb

        if (loud) {
            silenceMs = 0
            speechMs += durMs
            if (!inSpeech && speechMs >= startSpeechMs) inSpeech = true
            if (inSpeech) onSpeech(chunk)
        } else {
            speechMs = 0
            if (inSpeech) {
                silenceMs += durMs
                onSpeech(chunk)
                if (silenceMs >= endSilenceMs) {
                    inSpeech = false
                    silenceMs = 0
                    onSegmentEnd()
                }
            }
        }
    }

    fun reset() {
        inSpeech = false
        speechMs = 0
        silenceMs = 0
    }

    private fun rmsToDb(chunk: FloatArray): Float {
        var sum = 0.0
        for (v in chunk) sum += v.toDouble() * v.toDouble()
        val rms = sqrt(sum / chunk.size.coerceAtLeast(1))
        return (20 * log10(rms.coerceAtLeast(1e-8).toDouble())).toFloat()
    }
}
