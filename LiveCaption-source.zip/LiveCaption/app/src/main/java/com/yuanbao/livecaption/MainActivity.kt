package com.yuanbao.livecaption

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.yuanbao.livecaption.model.ModelManager
import com.yuanbao.livecaption.util.Prefs
import java.io.File

class MainActivity : AppCompatActivity() {

    companion object {
        // Vosk 官方中文小模型（约 80MB，离线、无需密钥）。
        // 也可换成其他中文模型 zip 直链，或按 README 用 adb push 导入。
        private const val DEFAULT_MODEL_URL =
            "https://alphacephei.com/vosk/models/vosk-model-small-cn-0.22.zip"
        private const val MAX_LINES = 8
    }

    private lateinit var rgMode: RadioGroup
    private lateinit var rgEngine: RadioGroup
    private lateinit var etSecretId: EditText
    private lateinit var etSecretKey: EditText
    private lateinit var tvModelState: TextView
    private lateinit var tvCaption: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnDownload: Button

    private var srtPath: String? = null

    private val captionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val text = intent.getStringExtra(CaptionService.EXTRA_TEXT)
            val error = intent.getStringExtra(CaptionService.EXTRA_ERROR)
            val state = intent.getStringExtra(CaptionService.EXTRA_STATE)
            intent.getStringExtra(CaptionService.EXTRA_SRT)?.let { if (it.isNotBlank()) srtPath = it }
            if (!error.isNullOrBlank()) {
                tvCaption.append("\n⚠ $error")
                toast(error)
            }
            if (!state.isNullOrBlank()) toast(state)
            if (!text.isNullOrBlank()) {
                tvCaption.append("\n$text")
                val lines = tvCaption.text.split("\n")
                if (lines.size > MAX_LINES) {
                    tvCaption.text = lines.takeLast(MAX_LINES).joinToString("\n")
                }
            }
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val audio = result[Manifest.permission.RECORD_AUDIO] == true
            if (!audio) {
                toast("需要录音权限才能识别音频")
                return@registerForActivityResult
            }
            requestProjectionOrStart()
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                startCaption(result.data!!)
            } else {
                toast("未授权屏幕捕获，已改用麦克风")
                startCaption(null)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rgMode = findViewById(R.id.rgMode)
        rgEngine = findViewById(R.id.rgEngine)
        etSecretId = findViewById(R.id.etSecretId)
        etSecretKey = findViewById(R.id.etSecretKey)
        tvModelState = findViewById(R.id.tvModelState)
        tvCaption = findViewById(R.id.tvCaption)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnDownload = findViewById(R.id.btnDownloadModel)

        rgMode.check(if (Prefs.getMode(this) == Prefs.MODE_INTERNAL) R.id.rbInternal else R.id.rbMic)
        rgEngine.check(if (Prefs.getEngine(this) == Prefs.ENGINE_LOCAL) R.id.rbLocal else R.id.rbCloud)
        etSecretId.setText(Prefs.getSecretId(this))
        etSecretKey.setText(Prefs.getSecretKey(this))
        syncEngineUi()
        refreshModelState()

        rgEngine.setOnCheckedChangeListener { _, _ -> syncEngineUi() }

        btnStart.setOnClickListener { onStartClick() }
        btnStop.setOnClickListener { stopCaption() }
        btnDownload.setOnClickListener { downloadModel() }
        findViewById<Button>(R.id.btnExport).setOnClickListener { exportSrt() }

        registerReceiver(captionReceiver, IntentFilter(CaptionService.BROADCAST_CAPTION))
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(captionReceiver) }
        super.onDestroy()
    }

    private fun syncEngineUi() {
        val cloud = rgEngine.checkedRadioButtonId == R.id.rbCloud
        etSecretId.visibility = if (cloud) View.VISIBLE else View.GONE
        etSecretKey.visibility = if (cloud) View.VISIBLE else View.GONE
    }

    private fun refreshModelState() {
        val ready = ModelManager.isReady(this)
        tvModelState.text = getString(
            R.string.model_state,
            if (ready) getString(R.string.model_ready) else getString(R.string.model_missing)
        )
    }

    private fun currentMode(): String =
        if (rgMode.checkedRadioButtonId == R.id.rbInternal) Prefs.MODE_INTERNAL else Prefs.MODE_MIC

    private fun currentEngine(): String =
        if (rgEngine.checkedRadioButtonId == R.id.rbCloud) Prefs.ENGINE_CLOUD else Prefs.ENGINE_LOCAL

    private fun onStartClick() {
        Prefs.setMode(this, currentMode())
        Prefs.setEngine(this, currentEngine())
        Prefs.saveCloudKeys(this, etSecretId.text.toString().trim(), etSecretKey.text.toString().trim())

        if (currentEngine() == Prefs.ENGINE_CLOUD &&
            (etSecretId.text.isBlank() || etSecretKey.text.isBlank())
        ) {
            toast("云端引擎需要填写 SecretId / SecretKey")
            return
        }
        if (currentEngine() == Prefs.ENGINE_LOCAL && !ModelManager.isReady(this)) {
            toast("请先下载离线模型")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("请先授予「显示在其他应用上层」权限")
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }

        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            requestProjectionOrStart()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun requestProjectionOrStart() {
        if (currentMode() == Prefs.MODE_INTERNAL && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
            projectionLauncher.launch(mgr.createScreenCaptureIntent())
        } else {
            startCaption(null)
        }
    }

    private fun startCaption(resultData: Intent?) {
        val intent = Intent(this, CaptionService::class.java).apply {
            action = CaptionService.ACTION_START
            putExtra(CaptionService.EXTRA_MODE, currentMode())
            putExtra(CaptionService.EXTRA_ENGINE, currentEngine())
            resultData?.let { putExtra(CaptionService.EXTRA_RESULT_DATA, it) }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        btnStart.isEnabled = false
        btnStop.isEnabled = true
        srtPath = null
        toast("字幕已开启，可切到其他 APP 查看悬浮窗")
    }

    private fun stopCaption() {
        startService(Intent(this, CaptionService::class.java).apply {
            action = CaptionService.ACTION_STOP
        })
        btnStart.isEnabled = true
        btnStop.isEnabled = false
    }

    private fun downloadModel() {
        btnDownload.isEnabled = false
        btnDownload.text = "下载中 0%"
        ModelManager.download(
            this,
            DEFAULT_MODEL_URL,
            onProgress = { percent, _ -> runOnUiThread { btnDownload.text = "下载中 $percent%" } },
            onDone = { ok, msg ->
                runOnUiThread {
                    btnDownload.isEnabled = true
                    btnDownload.text = getString(R.string.btn_download_model)
                    toast(msg ?: "完成")
                    refreshModelState()
                }
            }
        )
    }

    private fun exportSrt() {
        val file = srtPath?.let { File(it) }?.takeIf { it.exists() }
            ?: getExternalFilesDir("captions")?.listFiles()
                ?.filter { it.name.endsWith(".srt") }
                ?.maxByOrNull { it.lastModified() }

        if (file == null) {
            toast("还没有生成字幕文件")
            return
        }
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(share, "导出 SRT 字幕"))
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
