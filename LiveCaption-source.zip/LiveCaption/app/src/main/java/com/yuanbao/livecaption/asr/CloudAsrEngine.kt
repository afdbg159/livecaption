package com.yuanbao.livecaption.asr

import android.util.Base64
import android.util.Log
import com.yuanbao.livecaption.util.TCloudSigner
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/**
 * 云端中文识别：腾讯云 ASR「一句话识别」。
 * 在 VAD 判定一句话结束时把这段 PCM 送出，准确率高于小模型。
 * 需要 SecretId / SecretKey，按量计费，音频会上传到云端。
 */
class CloudAsrEngine(
    private val secretId: String,
    private val secretKey: String
) : AsrEngine {

    companion object {
        private const val TAG = "CloudAsrEngine"
        private const val HOST = "asr.tencentcloudapi.com"
        private const val SERVICE = "asr"
        private const val ACTION = "SentenceRecognition"
        private const val VERSION = "2019-06-14"
        private const val MAX_SECONDS = 55          // 一句话识别上限 60s
        private const val MIN_SECONDS = 0.3f        // 太短的片段直接丢弃
    }

    private val lock = Any()
    private var pcm = ByteArrayOutputStream()
    private var sampleRate = 16000

    override fun start(): Boolean {
        pcm.reset()
        return secretId.isNotBlank() && secretKey.isNotBlank()
    }

    override fun accept(samples: FloatArray, sampleRate: Int): String? {
        this.sampleRate = sampleRate
        val bytes = toPcm16(samples)
        val size = synchronized(lock) { pcm.write(bytes); pcm.size() }
        if (size >= sampleRate * 2 * MAX_SECONDS) return flush()
        return null
    }

    /** 云端一句话识别没有中间结果 */
    override fun partial(): String? = null

    override fun flush(): String? {
        val data = synchronized(lock) {
            val d = pcm.toByteArray()
            pcm.reset()
            d
        }
        if (data.isEmpty() || data.size < sampleRate * 2 * MIN_SECONDS) return null
        return try {
            request(data)
        } catch (t: Throwable) {
            Log.e(TAG, "cloud asr failed", t)
            null
        }
    }

    override fun release() {
        synchronized(lock) { pcm.reset() }
    }

    private fun toPcm16(samples: FloatArray): ByteArray {
        val out = ByteArray(samples.size * 2)
        for (i in samples.indices) {
            var v = samples[i]
            if (v > 1f) v = 1f
            if (v < -1f) v = -1f
            val s = (v * 32767f).roundToInt()
            out[i * 2] = (s and 0xFF).toByte()
            out[i * 2 + 1] = ((s shr 8) and 0xFF).toByte()
        }
        return out
    }

    private fun request(pcmData: ByteArray): String? {
        val payload = JSONObject().apply {
            put("ProjectId", 0)
            put("SubServiceType", 2)          // 一句话识别
            put("EngSerViceType", "16k_zh")   // 16k 中文普通话
            put("SourceType", 1)              // 音频数据
            put("VoiceFormat", "pcm")
            put("UsrAudioKey", "livecaption-${System.currentTimeMillis()}")
            put("DataLen", pcmData.size)
            put("Data", Base64.encodeToString(pcmData, Base64.NO_WRAP))
        }.toString()

        val ts = System.currentTimeMillis() / 1000
        val auth = TCloudSigner.sign(secretId, secretKey, HOST, SERVICE, ACTION, payload, ts)

        val conn = (URL("https://$HOST/").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 8_000
            readTimeout = 20_000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Host", HOST)
            setRequestProperty("X-TC-Action", ACTION)
            setRequestProperty("X-TC-Version", VERSION)
            setRequestProperty("X-TC-Timestamp", ts.toString())
            setRequestProperty("Authorization", auth)
        }

        return try {
            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val body = if (code in 200..299) {
                conn.inputStream.bufferedReader().readText()
            } else {
                conn.errorStream?.bufferedReader()?.readText().orEmpty()
            }
            if (code !in 200..299) {
                Log.e(TAG, "asr http $code: $body")
                null
            } else {
                JSONObject(body).optJSONObject("Response")?.optString("Result", "")?.ifBlank { null }
            }
        } finally {
            conn.disconnect()
        }
    }
}
