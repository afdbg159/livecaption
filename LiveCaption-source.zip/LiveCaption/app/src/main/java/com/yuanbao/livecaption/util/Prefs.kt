package com.yuanbao.livecaption.util

import android.content.Context

object Prefs {
    private const val NAME = "livecaption"

    private const val KEY_MODE = "mode"
    private const val KEY_ENGINE = "engine"
    private const val KEY_SECRET_ID = "secret_id"
    private const val KEY_SECRET_KEY = "secret_key"

    const val MODE_INTERNAL = "internal"   // MediaProjection 内录
    const val MODE_MIC = "mic"             // 麦克风

    const val ENGINE_LOCAL = "local"       // sherpa-onnx 本地离线
    const val ENGINE_CLOUD = "cloud"       // 腾讯云 ASR

    private fun sp(ctx: Context) = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun getMode(ctx: Context): String = sp(ctx).getString(KEY_MODE, MODE_INTERNAL) ?: MODE_INTERNAL
    fun setMode(ctx: Context, mode: String) = sp(ctx).edit().putString(KEY_MODE, mode).apply()

    fun getEngine(ctx: Context): String = sp(ctx).getString(KEY_ENGINE, ENGINE_LOCAL) ?: ENGINE_LOCAL
    fun setEngine(ctx: Context, engine: String) = sp(ctx).edit().putString(KEY_ENGINE, engine).apply()

    fun getSecretId(ctx: Context): String = sp(ctx).getString(KEY_SECRET_ID, "") ?: ""
    fun getSecretKey(ctx: Context): String = sp(ctx).getString(KEY_SECRET_KEY, "") ?: ""

    fun saveCloudKeys(ctx: Context, id: String, key: String) =
        sp(ctx).edit().putString(KEY_SECRET_ID, id).putString(KEY_SECRET_KEY, key).apply()
}
