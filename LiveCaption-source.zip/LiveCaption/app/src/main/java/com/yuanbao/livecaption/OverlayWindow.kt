package com.yuanbao.livecaption

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.util.Log

/**
 * 悬浮字幕窗：盖在其他 APP 之上显示识别出的中文文本，可上下拖动。
 */
class OverlayWindow(private val context: Context) {

    companion object {
        private const val TAG = "OverlayWindow"
    }

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var root: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var startRawY = 0f
    private var startY = 0

    fun show() {
        mainHandler.post {
            if (root != null) return@post
            val view = LayoutInflater.from(context).inflate(R.layout.overlay_caption, null)
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = 120
            }

            @SuppressLint("ClickableViewAccessibility")
            view.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startRawY = event.rawY
                        startY = p.y
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.y = (startY + (event.rawY - startRawY)).toInt()
                        runCatching { wm.updateViewLayout(view, p) }
                        true
                    }
                    else -> false
                }
            }

            runCatching { wm.addView(view, p) }
                .onFailure { Log.e(TAG, "addView failed", it) }
            root = view
            params = p
        }
    }

    fun update(text: String) {
        mainHandler.post {
            root?.findViewById<TextView>(R.id.tvCaption)?.text = text
        }
    }

    fun hide() {
        mainHandler.post {
            root?.let { runCatching { wm.removeView(it) } }
            root = null
            params = null
        }
    }
}
