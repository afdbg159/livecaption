package com.yuanbao.livecaption.model

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * Vosk 中文离线模型管理：查找、下载、解压。
 * 模型目录：<内部存储>/files/models/<模型名>/
 */
object ModelManager {

    private const val TAG = "ModelManager"

    fun rootDir(ctx: Context): File =
        File(ctx.filesDir, "models").apply { mkdirs() }

    /** 模型目录：含 final.mdl（或 am/final.mdl）即认为是 Vosk 模型 */
    fun findModelDir(ctx: Context): String? {
        val root = rootDir(ctx)
        scan(root)?.let { return it }
        root.listFiles()?.filter { it.isDirectory }?.forEach { d ->
            scan(d)?.let { return it }
            d.listFiles()?.filter { it.isDirectory }?.forEach { sub ->
                scan(sub)?.let { return it }
            }
        }
        return null
    }

    private fun scan(dir: File): String? {
        if (!dir.isDirectory) return null
        val hasModel = File(dir, "final.mdl").isFile || File(dir, "am/final.mdl").isFile
        return if (hasModel) dir.absolutePath else null
    }

    fun isReady(ctx: Context): Boolean = findModelDir(ctx) != null

    /** 后台线程下载并解压 zip 模型包 */
    fun download(
        ctx: Context,
        urlStr: String,
        onProgress: (percent: Int, bytes: Long) -> Unit,
        onDone: (ok: Boolean, message: String?) -> Unit
    ) {
        Thread {
            try {
                val root = rootDir(ctx)
                val fileName = urlStr.substringAfterLast('/').substringBefore('?').ifBlank { "model.zip" }
                val tmp = File(root, fileName)

                val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = true
                    connectTimeout = 20_000
                    readTimeout = 120_000
                }
                conn.connect()
                val code = conn.responseCode
                if (code !in 200..299) {
                    conn.disconnect()
                    onDone(false, "下载失败，HTTP $code")
                    return@Thread
                }
                val total = conn.contentLength.toLong()
                var done = 0L
                conn.inputStream.use { input ->
                    FileOutputStream(tmp).use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) onProgress((done * 100 / total).toInt(), done)
                        }
                    }
                }
                conn.disconnect()

                unzip(tmp, root)
                tmp.delete()

                val dir = findModelDir(ctx)
                if (dir == null) {
                    onDone(false, "解压完成但未找到模型，请检查压缩包内容")
                } else {
                    onDone(true, "模型已就绪，可以开始字幕")
                }
            } catch (t: Throwable) {
                Log.e(TAG, "download failed", t)
                onDone(false, t.message ?: "下载失败")
            }
        }.apply { name = "model-download" }.start()
    }

    private fun unzip(zip: File, destDir: File) {
        destDir.mkdirs()
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            while (true) {
                val entry: ZipEntry = zis.nextEntry ?: break
                val target = safeChild(destDir, entry.name) ?: continue
                if (entry.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { out -> zis.copyTo(out) }
                }
                zis.closeEntry()
            }
        }
    }

    /** 防止 zip slip 路径穿越 */
    private fun safeChild(base: File, name: String): File? {
        if (name.isBlank()) return null
        val clean = name.replace('\\', '/')
        if (clean.contains("../") || clean.startsWith("/")) return null
        return File(base, clean)
    }
}
