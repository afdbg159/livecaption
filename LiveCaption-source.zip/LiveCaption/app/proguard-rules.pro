# 保留 sherpa-onnx 的 JNI 与反射入口
-keep class com.k2fsa.sherpa.onnx.** { *; }
-keep class org.apache.commons.compress.** { *; }
-dontwarn org.apache.commons.compress.**

# 数据类字段在反射/序列化场景保留
-keepclassmembers class com.yuanbao.livecaption.** { <fields>; }
