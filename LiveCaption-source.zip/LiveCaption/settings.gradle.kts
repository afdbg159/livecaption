pluginManagement {
    repositories {
        // 腾讯云 Nexus 代理（含 Google / MavenCentral / Gradle 插件仓库）
        maven("https://mirrors.cloud.tencent.com/nexus/repository/maven-public/")
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        maven("https://mirrors.cloud.tencent.com/nexus/repository/maven-public/")
    }
}

rootProject.name = "LiveCaption"
include(":app")
