# 实时中文字幕 LiveCaption

捕获手机里正在播放的声音（任意 APP 的中文音频），实时转成中文，以**悬浮窗字幕**盖在其他 APP 之上，并同步落盘为 **SRT 字幕文件**。

- 音频：Android 10+ `MediaProjection` 内录（只收 APP 播放声）；不支持时自动降级麦克风
- 识别：默认 **Vosk 离线中文模型**（不联网、不上传音频）；可选腾讯云 ASR（需密钥）
- 呈现：悬浮窗（可拖动）+ App 内回显 + SRT 导出

---

## 没有电脑？用 GitHub Actions 云端编译（推荐）

原理：把源码交给 GitHub 的免费云端服务器编译，产出的 APK 在 Release 里，手机浏览器直接下载安装。

### 第 1 步：新建仓库
手机浏览器打开 `github.com`（没有账号就注册一个，免费）→ 右上角 `+` → **New repository**
- Repository name：`livecaption`
- 勾选 **Public**（私有仓库 Actions 有额度限制）
- 勾选 **Add a README file**
- 点 **Create repository**

### 第 2 步：上传源码
在仓库页面点 **Add file → Upload files**，选择 `LiveCaption-source.zip` 上传，底部点 **Commit changes**。
（手机浏览器从"文件/下载"里选这个 zip 即可）

### 第 3 步：创建编译脚本
在仓库页面点 **Add file → Create new file**，文件名一栏**完整输入**：

```
.github/workflows/build-apk.yml
```

（GitHub 会自动创建这两级目录）内容粘贴 `build-apk.yml` 里的文本，然后 **Commit changes**。

### 第 4 步：跑编译、拿 APK
- 顶部点 **Actions** → 左侧 **Build APK** → 右侧 **Run workflow** → **Run workflow**
- 约 3～8 分钟后变绿 ✅，点进这次运行，最下方 **Artifacts** 里的 `LiveCaption-debug-apk` 可直接下载
- 更省事：回仓库首页，右侧 **Releases** 里也有同一个 APK（文件名 `app-debug.apk`，可直接下载安装）

### 第 5 步：安装
下载完点 APK → 允许"安装未知应用" → 安装。首次打开按提示授予**录音权限**和**显示在其他应用上层**。

> 以后改代码再提交，Actions 会自动重新编译出新 APK。

---

## 有电脑时的本地编译

```bash
# local.properties 里写自己的 sdk.dir，或设置 ANDROID_HOME
./gradlew assembleDebug          # 若没有 wrapper，先 gradle wrapper
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
需要 JDK 17 + Android SDK（compileSdk 34），minSdk 29。

---

## 首次使用

1. 打开 APP → 保持「APP 内录」+「本地离线」→ 点 **下载离线模型**（约 80MB，中文小模型，只需一次）
2. 授权录音权限 + 悬浮窗权限
3. 点 **开始字幕** → 系统弹"是否允许录制屏幕内容"，允许
4. 切到视频/语音 APP，屏幕顶部出现中文字幕
5. 结束后点 **导出 SRT 字幕** 分享 `.srt` 文件

### 用云端引擎（可选）
腾讯云控制台开通「语音识别」，拿到 SecretId / SecretKey，APP 内选「云端」填入即可（准确率更高，但音频会上传云端，按量计费）。

---

## 目录结构

```
app/src/main/java/com/yuanbao/livecaption/
├── MainActivity.kt        # 权限、模式/引擎选择、模型下载、导出 SRT
├── CaptionService.kt      # 前台服务：采集 → 识别 → 字幕
├── OverlayWindow.kt       # 悬浮字幕窗（可拖动）
├── audio/AudioCapture.kt  # 内录 / 麦克风
├── audio/VadSegmenter.kt  # 断句
├── asr/VoskEngine.kt      # 本地离线引擎
├── asr/CloudAsrEngine.kt  # 腾讯云 ASR
├── model/ModelManager.kt  # 模型查找 / 下载 / 解压
└── util/                  # 配置、SRT 写入、TC3 签名
.github/workflows/build-apk.yml   # 云端编译脚本
```

## 常见问题

- **内录没声音 / 提示切麦克风**：部分 APP 禁止被捕获（如声明 FLAG_SECURE），这是系统限制，只能改用麦克风模式。
- **识别慢或发热**：换更小的模型，或降低 `CaptionService` 里的线程数；内录时把音量调大、环境安静。
- **断句不理想**：调 `VadSegmenter` 的 `endSilenceMs`（默认 600ms）和 `speechDb`（默认 -45dB）。
- **模型下载失败**：换网络重试；也可解压模型 zip 后整个文件夹放进
  `手机内部存储/Android/data/com.yuanbao.livecaption/files/models/`。

## 合规提醒

录音与实时字幕涉及隐私，请在你自己拥有或已获授权的内容上使用。
