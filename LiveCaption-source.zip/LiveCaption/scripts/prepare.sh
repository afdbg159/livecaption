#!/usr/bin/env bash
# 准备构建依赖：
#   1) 下载 sherpa-onnx Android aar 到 app/libs/
#   2) 下载中文流式 ASR 模型并解压到 ./models/（可用 adb push 推到手机）
set -euo pipefail

SHERPA_VERSION="${SHERPA_VERSION:-1.10.29}"
ABI="${ABI:-arm64-v8a}"
MODEL="${MODEL:-sherpa-onnx-streaming-zipformer-zh-14M-2023-02-23}"
MODEL_BASE="https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LIBS="$ROOT/app/libs"
MODELS="$ROOT/models"

mkdir -p "$LIBS" "$MODELS"

echo "==> 1/2 下载 sherpa-onnx aar ($SHERPA_VERSION / $ABI)"
AAR="sherpa-onnx-${SHERPA_VERSION}-android-${ABI}.aar"
if [ ! -f "$LIBS/$AAR" ]; then
  for TAG in "v${SHERPA_VERSION}" "${SHERPA_VERSION}"; do
    URL="https://github.com/k2-fsa/sherpa-onnx/releases/download/${TAG}/${AAR}"
    echo "    尝试 $URL"
    if curl -fL --retry 2 -o "$LIBS/$AAR" "$URL"; then
      echo "    已保存 $LIBS/$AAR"
      break
    fi
    rm -f "$LIBS/$AAR"
  done
  if [ ! -f "$LIBS/$AAR" ]; then
    echo "!! 自动下载失败，请手动从 https://github.com/k2-fsa/sherpa-onnx/releases"
    echo "!! 下载对应版本的 android aar，重命名为 sherpa-onnx.aar 放入 app/libs/"
    exit 1
  fi
fi
# 统一成固定文件名，方便 build.gradle 引用
cp -f "$LIBS/$AAR" "$LIBS/sherpa-onnx.aar"

echo "==> 2/2 下载中文模型 $MODEL"
if [ ! -d "$MODELS/$MODEL" ]; then
  curl -fL --retry 2 -o "$MODELS/${MODEL}.tar.bz2" "${MODEL_BASE}/${MODEL}.tar.bz2"
  tar -xf "$MODELS/${MODEL}.tar.bz2" -C "$MODELS"
  rm -f "$MODELS/${MODEL}.tar.bz2"
fi
echo "    模型目录：$MODELS/$MODEL"

PKG_DIR="/sdcard/Android/data/com.yuanbao.livecaption/files/models"
cat <<EOF

准备完成。接下来：

  A. 手机内直接下载：安装 APK 后点「下载离线模型」（App 内联网下载，约 40MB）

  B. 电脑导入（省流量，推荐）：
       adb shell mkdir -p $PKG_DIR
       adb push "$MODELS/$MODEL" "$PKG_DIR/$MODEL"

  C. 编译安装：
       cd "$ROOT" && ./gradlew assembleDebug && adb install -r app/build/outputs/apk/debug/app-debug.apk
EOF
